El contrato de ejemplo es MyAccessControlledContract.sol.
Mi contrato de ejemplo usa los contratos de ejemplo de OpenZeppelin: AccessControl.sol e IAccessControl.sol.